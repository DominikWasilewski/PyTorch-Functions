import requests
import zipfile
from pathlib import Path

def data_preparation(dataset_name: str, github_url: str):
    """
    Downloads and unzips dataset from a given GitHub URL.

    Args:
        dataset_name (str): The name of the dataset (used for naming directories and files).
        github_url (str): The GitHub URL to download the dataset from.

    Returns:
        Path: The path to the extracted dataset.
    """
    data_path = Path("data/")
    image_path = data_path / dataset_name
    zip_path = data_path / f"{dataset_name}.zip"

    if image_path.is_dir():
            print("Skipping")
    else:
        image_path.mkdir(parents=True, exist_ok=True)

    if not zip_path.exists():
        with open(zip_path, "wb") as f:
            print("Downloading zip file...")
            response = requests.get(github_url)
            f.write(response.content)
    else:
        print(f"{zip_path} already exists. Skipping download.")

    if not image_path.exists():
        print("Unzipping the dataset...")
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(image_path)
    else:
        print(f"Dataset already unzipped at {image_path}. Skipping unzipping.")

    return image_path




    