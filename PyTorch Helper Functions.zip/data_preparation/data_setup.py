import torch
from torchvision import transforms
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder

def create_dataloaders(train_dir: str,
                       test_dir: str,
                       batch_size: int,
                       picture_size: int,
                       num_workers: int = 2):
    """
    Creates DataLoader objects for training and testing datasets.

    This function takes in the directory paths for the training and testing datasets, 
    applies the necessary transformations (such as resizing and converting to tensors), 
    and returns DataLoader objects for both the training and testing datasets along with 
    the class names present in the dataset.

    Args:
        train_dir (str): Path to the training dataset directory, which is passed to ImageFolder.
        test_dir (str): Path to the testing dataset directory, which is passed to ImageFolder.
        batch_size (int): Number of samples in each batch in the DataLoader.
        picture_size (int): Size to resize the images to (picture_size x picture_size).
        num_workers (int, optional): Number of CPU cores to use for loading data. Defaults to 2.

    Returns:
        tuple: A tuple containing:
            - train_dataloader (DataLoader): DataLoader object for the training dataset.
            - test_dataloader (DataLoader): DataLoader object for the testing dataset.
            - class_names (List[str]): List of class names corresponding to the dataset.
    """
    data_transfom = transforms.Compose([
        transforms.Resize(size=(picture_size, picture_size)),
        transforms.ToTensor()
    ])
    train_ImageFolder = ImageFolder(root=train_dir,
                                    transform=data_transfom)
    
    test_ImageFolder = ImageFolder(root=test_dir,
                                    transform=data_transfom)
    
    class_names = train_ImageFolder.classes

    train_dataloader = DataLoader(dataset=train_ImageFolder,
                                  shuffle=True,
                                  pin_memory=True,
                                  batch_size=batch_size,
                                  num_workers=num_workers)
    
    test_dataloader = DataLoader(dataset=test_ImageFolder,
                                  shuffle=False,
                                  pin_memory=True,
                                  batch_size=batch_size,
                                  num_workers=num_workers)
    
    return train_dataloader, test_dataloader, class_names
