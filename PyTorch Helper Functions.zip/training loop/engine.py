import torch
from typing import Dict, List, Tuple
from tqdm import tqdm

def train_step(model: torch.nn.Module,
               dataloader: torch.utils.data.DataLoader,
               loss_fn: torch.nn.Module,
               optimizer: torch.optim.Optimizer) -> Tuple[float, float]:
    """
    Performs a single training step for a PyTorch model.

    Args:
        model (torch.nn.Module): The model to be trained.
        dataloader (torch.utils.data.DataLoader): DataLoader providing batches of training data.
        loss_fn (torch.nn.Module): The loss function to optimize.
        optimizer (torch.optim.Optimizer): The optimizer used to update the model's parameters.

    Returns:
        Tuple[float, float]: A tuple containing:
            - train_loss (float): The average loss over the entire training dataset.
            - train_acc (float): The average accuracy over the entire training dataset.
    """
    model.train()
    train_loss, train_acc = 0, 0
    for batch, (X, y) in enumerate(dataloader):
        y_pred = model(X)
        loss = loss_fn(y_pred, y)
        train_loss += loss.item()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        y_pred_class = torch.argmax(torch.softmax(y_pred, dim=1), dim=1)
        train_acc += (y_pred_class == y).sum().item() / len(y_pred)
    train_loss = train_loss / len(dataloader)
    train_acc = train_acc / len(dataloader)
    return train_loss, train_acc

def test_step(model: torch.nn.Module,
              dataloader: torch.utils.data.DataLoader,
              loss_fn: torch.nn.Module) -> Tuple[float, float]:
    """
    Performs a single evaluation step for a PyTorch model on a test dataset.

    Args:
        model (torch.nn.Module): The model to be evaluated.
        dataloader (torch.utils.data.DataLoader): DataLoader providing batches of testing data.
        loss_fn (torch.nn.Module): The loss function to compute test loss.

    Returns:
        Tuple[float, float]: A tuple containing:
            - test_loss (float): The average loss over the entire test dataset.
            - test_acc (float): The average accuracy over the entire test dataset.
    """
    model.eval()
    test_loss, test_acc = 0, 0
    with torch.inference_mode():
        for batch, (X, y) in enumerate(dataloader):
            test_pred_logits = model(X)
            loss = loss_fn(test_pred_logits, y)
            test_loss += loss.item()
            test_pred_labels = test_pred_logits.argmax(dim=1)
            test_acc += (test_pred_labels == y).sum().item() / len(test_pred_labels)
    test_loss = test_loss / len(dataloader)
    test_acc = test_acc / len(dataloader)
    return test_loss, test_acc

def train(model: torch.nn.Module,
          train_dataloader: torch.utils.data.DataLoader,
          test_dataloader: torch.utils.data.DataLoader,
          optimizer: torch.optim.Optimizer,
          loss_fn: torch.nn.Module,
          epochs: int) -> Dict[str, List]:
    """
    Trains and evaluates a PyTorch model for a specified number of epochs.

    During each epoch, the function runs the training step on the training dataset 
    and the evaluation step on the test dataset. The loss and accuracy for both
    training and testing are printed and stored.

    Args:
        model (torch.nn.Module): The model to be trained and tested.
        train_dataloader (torch.utils.data.DataLoader): DataLoader for the training dataset.
        test_dataloader (torch.utils.data.DataLoader): DataLoader for the test dataset.
        optimizer (torch.optim.Optimizer): The optimizer used for training.
        loss_fn (torch.nn.Module): The loss function used for training and evaluation.
        epochs (int): The number of epochs to train the model.

    Returns:
        Dict[str, List]: A dictionary containing lists of loss and accuracy values for both
                         training and testing over each epoch. Keys are:
                         - 'train_loss': List of training loss values per epoch.
                         - 'train_acc': List of training accuracy values per epoch.
                         - 'test_loss': List of test loss values per epoch.
                         - 'test_acc': List of test accuracy values per epoch.
    """
    results = {"train_loss": [], "train_acc": [], "test_loss": [], "test_acc": []}
    for epoch in tqdm(range(epochs)):
        train_loss, train_acc = train_step(model=model,
                                           dataloader=train_dataloader,
                                           loss_fn=loss_fn,
                                           optimizer=optimizer)
        test_loss, test_acc = test_step(model=model,
                                        dataloader=test_dataloader,
                                        loss_fn=loss_fn)
        print(f"Epoch: {epoch+1} | train_loss: {train_loss:.4f} | train_acc: {train_acc:.4f} | test_loss: {test_loss:.4f} | test_acc: {test_acc:.4f}")
        results["train_loss"].append(train_loss)
        results["train_acc"].append(train_acc)
        results["test_loss"].append(test_loss)
        results["test_acc"].append(test_acc)
    return results
