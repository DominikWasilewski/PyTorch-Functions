from torch import nn
import torch
class TinyVGG(nn.Module):
    """
    A simplified version of the VGG-style Convolutional Neural Network.

    This model consists of two convolutional blocks, each containing two convolutional layers 
    followed by ReLU activation and max pooling. It is designed for image classification tasks.

    Args:
        input_shape (int): Number of input channels (e.g., 3 for RGB images or 1 for grayscale).
        hidden_units (int): Number of filters (feature maps) in the convolutional layers.
        output_shape (int): Number of output classes for classification.

    Layers:
        - block_1: Two convolutional layers with ReLU activation, followed by max pooling.
        - block_2: Two more convolutional layers with ReLU activation, followed by max pooling.
        - classifier: A fully connected (dense) layer that flattens the output of the convolutional layers 
          and outputs the final predictions.

    Forward Pass:
        The input passes through the two convolutional blocks (block_1 and block_2), then it is flattened
        and passed through a fully connected layer (classifier) to produce the final output.

    Example:
        model = TinyVGG(input_shape=3, hidden_units=128, output_shape=10)
        x = torch.randn(1, 3, 224, 224)  # Random input (batch size 1, 3 channels, 224x224 image)
        preds = model(x)  # Forward pass

    Returns:
        torch.Tensor: Output tensor containing the predicted class scores (logits).

    """
    def __init__(self, input_shape: int, hidden_units: int, output_shape:int):
        super().__init__()
        self.block_1 = nn.Sequential(
            nn.Conv2d(input_shape, hidden_units, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2)
        )
        self.block_2 = nn.Sequential(
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(hidden_units* 16 * 16, output_shape)
        )

    def forward(self, x: torch.Tensor):
        x = self.block_1(x)
        print(f"x shape after 1 block: {x.shape}")
        x = self.block_2(x)
        print(f"x shape after 2 block: {x.shape}")
        x = self.classifier(x)
        print(f"x shape after classifier: {x.shape}")
        return x

